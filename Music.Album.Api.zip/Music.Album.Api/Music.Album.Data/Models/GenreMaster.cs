﻿using System;
using System.Collections.Generic;

namespace Music.Album.Data.Models
{
    public partial class GenreMaster
    {
        public GenreMaster()
        {
            AlbumtypeMaster = new HashSet<AlbumtypeMaster>();
            MusicMaster = new HashSet<MusicMaster>();
        }

        public int GenreId { get; set; }
        public string GenereName { get; set; }

        public virtual ICollection<AlbumtypeMaster> AlbumtypeMaster { get; set; }
        public virtual ICollection<MusicMaster> MusicMaster { get; set; }
    }
}
