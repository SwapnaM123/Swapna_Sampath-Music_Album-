﻿using System;
using System.Collections.Generic;

namespace Music.Album.Data.Models
{
    public partial class MusicMaster
    {
        public int MusicId { get; set; }
        public int? AlbumId { get; set; }
        public int? TitleId { get; set; }
        public int? ArtistId { get; set; }
        public int? GenreId { get; set; }

        public virtual AlbumtypeMaster Album { get; set; }
        public virtual ArtistMaster Artist { get; set; }
        public virtual GenreMaster Genre { get; set; }
        public virtual TitleMaster Title { get; set; }
    }
}
