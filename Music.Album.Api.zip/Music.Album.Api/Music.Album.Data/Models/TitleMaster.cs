﻿using System;
using System.Collections.Generic;

namespace Music.Album.Data.Models
{
    public partial class TitleMaster
    {
        public TitleMaster()
        {
            ArtistMaster = new HashSet<ArtistMaster>();
            MusicMaster = new HashSet<MusicMaster>();
        }

        public int TitleId { get; set; }
        public string TitleName { get; set; }
        public int? AlbumId { get; set; }

        public virtual AlbumtypeMaster Album { get; set; }
        public virtual ICollection<ArtistMaster> ArtistMaster { get; set; }
        public virtual ICollection<MusicMaster> MusicMaster { get; set; }
    }
}
