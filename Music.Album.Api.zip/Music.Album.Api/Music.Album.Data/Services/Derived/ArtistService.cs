﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Music.Album.Data.Models;
//using Music.Album.Api.Models;
using Music.Album.Data.Services.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Music.Album.Data.Services.Derived
{
    public class ArtistService : IArtistService
    {
        private readonly musicContext _musicContext;
        private readonly IConfiguration _iconfiguration;
        public ArtistService(IConfiguration iconfiguration, musicContext musiccontext)
        {
            _iconfiguration = iconfiguration;
            _musicContext = musiccontext;
        }
        public ArtistMaster CreateArtist(ArtistMaster artistMaster)
        {
            _musicContext.ArtistMaster.Add(artistMaster);
            _musicContext.SaveChanges();
            return artistMaster;
        }

        public ArtistMaster DeleteArtist(ArtistMaster artistMaster)
        {
            _musicContext.Entry(artistMaster).State = EntityState.Deleted;
            _musicContext.SaveChanges();
            return artistMaster;
        }

        public ArtistMaster GetArtistById(int titleid)
        {

            var data = _musicContext.ArtistMaster.Where(x => x.TitleId == titleid).FirstOrDefault();
            try
            {
                if (data != null)
                {
                    _musicContext.ArtistMaster.ToList();
                }
            }
            catch (DbUpdateException ex)
            {

            }
            return data;
        }

        public List<ArtistMaster> GetAllArtists()
        {
            List<ArtistMaster> artistMasters = _musicContext.ArtistMaster.ToList();
            return artistMasters;
        }


        public ArtistMaster UpdateArtist(ArtistMaster artistMaster)
        {
            ArtistMaster model = _musicContext.ArtistMaster.Where(x => x.ArtistId == artistMaster.ArtistId).FirstOrDefault();
            if (model != null)
            {
                model.ArtistName = string.IsNullOrEmpty(artistMaster.ArtistName) ? model.ArtistName : artistMaster.ArtistName;
                model.Profession = string.IsNullOrEmpty(artistMaster.Profession) ? model.Profession : artistMaster.Profession;
                _musicContext.Entry(model).State = EntityState.Modified;
                _musicContext.SaveChanges();
                return artistMaster;
            }
            else
            {
                return artistMaster;
            }
        }
    }
}
