﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Music.Album.Data.Models;
//using Music.Album.Api.Models;
using Music.Album.Data.Services.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Music.Album.Data.Services.Derived
{
    public class GenreService : IGenreService
    {
        private readonly musicContext _musicContext;
        private readonly IConfiguration _iconfiguration;
        public GenreService(IConfiguration iconfiguration, musicContext musicContext)
        {
            _iconfiguration = iconfiguration;
            _musicContext = musicContext;
        }
        public GenreMaster CreateGenre(GenreMaster genreMaster)
        {
            _musicContext.GenreMaster.Add(genreMaster);
            _musicContext.SaveChanges();
            return genreMaster;
        }

        public GenreMaster DeleteGenre(GenreMaster genreMaster)
        {
            _musicContext.Entry(genreMaster).State = EntityState.Deleted;
            _musicContext.SaveChanges();
            return genreMaster;
        }

        public List<GenreMaster> GetAllGenre()
        {
            return _musicContext.GenreMaster.ToList();
        }

        public GenreMaster GetByIdGenre(GenreMaster genreMaster)
        {
            GenreMaster genre = _musicContext.GenreMaster.Find(genreMaster.GenreId);
            return genre;
        }

        public GenreMaster UpdateGenre(GenreMaster genreMaster)
        {
            GenreMaster model = _musicContext.GenreMaster.Where(x => x.GenreId == genreMaster.GenreId).FirstOrDefault();
            if (model != null)
            {
                model.GenereName = string.IsNullOrEmpty(genreMaster.GenereName) ? model.GenereName : genreMaster.GenereName;

                _musicContext.Entry(model).State = EntityState.Modified;
                _musicContext.SaveChanges();
                return genreMaster;
            }
            else
            {
                return genreMaster;
            }
        }
    }
}
