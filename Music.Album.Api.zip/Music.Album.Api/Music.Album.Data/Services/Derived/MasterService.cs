﻿
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Music.Album.Data.Models;
using Music.Album.Data.Services.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Music.Album.Data.Services.Derived
{
    public class MasterService : IMasterService
    {
        private readonly musicContext _musiccontext;
        private readonly IConfiguration _iconfiguration;

        public MasterService(IConfiguration iconfiguration, musicContext musiccontext)
        {
            _iconfiguration = iconfiguration;
            _musiccontext = musiccontext;
        }

        public AlbumtypeMaster CreateAlbum(AlbumtypeMaster albumTypeMaster)
        {
            _musiccontext.AlbumtypeMaster.Add(albumTypeMaster);
            _musiccontext.SaveChanges();
            return albumTypeMaster;
        }

        public AlbumtypeMaster DeleteAlbum(AlbumtypeMaster albumTypeMaster)
        {
            _musiccontext.Entry(albumTypeMaster).State = EntityState.Deleted;
            _musiccontext.SaveChanges();
            return albumTypeMaster;
        }

        public List<string> GetAllAlbums()
        {
            List<string> albumtypeMasters = _musiccontext.AlbumtypeMaster.Select(x => x.AlbumName).ToList();
            return albumtypeMasters;
        }

        public List<AlbumtypeMaster> GetAlbumById(int genreid)
        {
            var data = _musiccontext.AlbumtypeMaster.Where(x => x.GenreId == genreid).ToList();
            try
            {
                if (data != null)
                {
                    _musiccontext.AlbumtypeMaster.ToList();
                }
            }
            catch (DbUpdateException ex)
            {

            }
            return data;
        }


        public AlbumtypeMaster UpdateAlbum(AlbumtypeMaster albumTypeMaster)
        {
            AlbumtypeMaster model = _musiccontext.AlbumtypeMaster.Where(x => x.AlbumId == albumTypeMaster.AlbumId).FirstOrDefault();
            if (model != null)
            {
                model.AlbumName = string.IsNullOrEmpty(albumTypeMaster.AlbumName) ? model.AlbumName : albumTypeMaster.AlbumName;
                model.Year = albumTypeMaster.Year == 0 ? model.Year : albumTypeMaster.Year;
                _musiccontext.Entry(model).State = EntityState.Modified;
                _musiccontext.SaveChanges();
                return albumTypeMaster;
            }
            else
            {
                return albumTypeMaster;
            }

        }


    }
}
