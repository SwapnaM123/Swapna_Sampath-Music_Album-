﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
//using Music.Album.Api.Models;
using Music.Album.Data.Models;
using Music.Album.Data.Services.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Music.Album.Data.Services.Derived
{
    public class TitleService : ITitleService
    {
        private readonly musicContext _musiccontext;
        private readonly IConfiguration _iconfiguration;
        public TitleService(IConfiguration iconfiguration, musicContext musiccontext)
        {
            _iconfiguration = iconfiguration;
            _musiccontext = musiccontext;
        }
        public TitleMaster CreateTitle(TitleMaster titleMaster)
        {
            _musiccontext.Add(titleMaster);
            _musiccontext.SaveChanges();
            return titleMaster;
        }

        public TitleMaster DeleteTitle(TitleMaster titleMaster)
        {
            _musiccontext.Entry(titleMaster).State = EntityState.Deleted;
            _musiccontext.SaveChanges();
            return titleMaster;
        }

        public List<string> GetAllTitles()
        {
            List<string> titleMaster = _musiccontext.TitleMaster.Select(x => x.TitleName).ToList();
            return titleMaster;
        }

        public List<TitleMaster> GetTitleById(int albumid)
        {
            var data = _musiccontext.TitleMaster.Where(x => x.AlbumId == albumid).ToList();
            try
            {
                if (data != null)
                {
                    _musiccontext.TitleMaster.ToList();
                }
            }
            catch (DbUpdateException ex)
            {

            }
            return data;
        }

        public TitleMaster UpdateTitle(TitleMaster titleMaster)
        {
            TitleMaster model = _musiccontext.TitleMaster.Where(x => x.TitleId == titleMaster.TitleId).FirstOrDefault();
            if (model != null)
            {
                model.TitleName = string.IsNullOrEmpty(titleMaster.TitleName) ? model.TitleName : titleMaster.TitleName;

                _musiccontext.Entry(model).State = EntityState.Modified;
                _musiccontext.SaveChanges();
                return titleMaster;
            }
            else
            {
                return titleMaster;
            }
        }
    }
}
