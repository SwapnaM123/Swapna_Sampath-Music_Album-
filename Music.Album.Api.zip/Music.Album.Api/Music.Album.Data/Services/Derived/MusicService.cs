﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Music.Album.Data.Models;
//using Music.Album.Api.Models;
using Music.Album.Data.Services.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Music.Album.Data.Services.Derived
{
    public class MusicService : IMusicService
    {
        private readonly musicContext _musicContext;
        private readonly IConfiguration _iconfiguration;
        public MusicService(IConfiguration iconfiguration, musicContext musiccontext)
        {
            _iconfiguration = iconfiguration;
            _musicContext = musiccontext;
        }
        public MusicMaster CreateMusic(MusicMaster musicMaster)
        {
            _musicContext.MusicMaster.Add(musicMaster);
            _musicContext.SaveChanges();
            return musicMaster;
        }

        public MusicMaster DeleteMusic(MusicMaster musicMaster)
        {
            _musicContext.Entry(musicMaster).State = EntityState.Deleted;
            _musicContext.SaveChanges();
            return musicMaster;
        }

        public List<MusicMaster> GetAllMusics()
        {
            List<MusicMaster> musicMasters = _musicContext.MusicMaster.ToList();
            return musicMasters;
        }

        public Object GetMusic(MusicDetailsViewModel m)
        {
            var data = from mm in _musicContext.MusicMaster
                       join gm in _musicContext.GenreMaster on mm.GenreId equals gm.GenreId
                       join am in _musicContext.AlbumtypeMaster on mm.AlbumId equals am.AlbumId
                       join tm in _musicContext.TitleMaster on mm.TitleId equals tm.TitleId
                       join arm in _musicContext.ArtistMaster on mm.ArtistId equals arm.ArtistId

                       where gm.GenereName == (m.GenereName == "" ? gm.GenereName : m.GenereName)
                       where am.AlbumName == (m.AlbumName == "" ? am.AlbumName : m.AlbumName)
                       where tm.TitleName == (m.TitleName == "" ? tm.TitleName : m.TitleName)
                       where arm.ArtistName == (m.ArtistName == "" ? arm.ArtistName : m.ArtistName)
                       where arm.MusicdirectorName == (m.MusicdirectorName == "" ? arm.MusicdirectorName : m.MusicdirectorName)
                       select new MusicDetailsViewModel
                       {
                           GenereName = gm.GenereName,
                           AlbumName = am.AlbumName,
                           TitleName = tm.TitleName,
                           ArtistName = arm.ArtistName,
                           MusicdirectorName = arm.MusicdirectorName
                       };

            return data;
        }

        public MusicMaster GetMusicById(MusicMaster musicMaster)
        {
            var data = _musicContext.MusicMaster.Where(x => x.MusicId == musicMaster.MusicId).FirstOrDefault();
            try
            {
                if (data != null)
                {
                    _musicContext.MusicMaster.ToList();
                }
            }
            catch (DbUpdateException ex)
            {

            }
            return data;
        }


        public MusicMaster UpdateMusic(MusicMaster musicMaster)
        {
            MusicMaster model = _musicContext.MusicMaster.Where(x => x.MusicId == musicMaster.MusicId).FirstOrDefault();
            if (model != null)
            {
                model.AlbumId = (musicMaster.AlbumId == null) ? model.AlbumId : musicMaster.AlbumId;
                model.TitleId = (musicMaster.TitleId == null) ? model.TitleId : musicMaster.TitleId;
                model.ArtistId = (musicMaster.ArtistId == null) ? model.ArtistId : musicMaster.ArtistId;
                model.GenreId = (musicMaster.GenreId == null) ? model.GenreId : musicMaster.GenreId;
                _musicContext.Entry(model).State = EntityState.Modified;
                _musicContext.SaveChanges();
                return musicMaster;
            }
            else
            {
                return musicMaster;
            }
        }
    }
}
