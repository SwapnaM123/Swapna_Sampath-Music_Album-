﻿//using Music.Album.Api.Models;
using Music.Album.Data.Models;
using Music.Album.Data.Services.Derived;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Music.Album.Data.Services.Abstract
{
    public interface IMusicService
    {
        MusicMaster CreateMusic(MusicMaster musicMaster);
        MusicMaster UpdateMusic(MusicMaster musicMaster);
        MusicMaster DeleteMusic(MusicMaster musicMaster);
        List<MusicMaster> GetAllMusics();
        MusicMaster GetMusicById(MusicMaster musicMaster);
        Object GetMusic(MusicDetailsViewModel m);
    }
}
