﻿
//using Music.Album.Api.Models;
using Music.Album.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Music.Album.Data.Services.Abstract
{
    public interface IMasterService
    {
        AlbumtypeMaster CreateAlbum(AlbumtypeMaster albumTypeMaster);
        AlbumtypeMaster UpdateAlbum(AlbumtypeMaster albumTypeMaster);
        AlbumtypeMaster DeleteAlbum(AlbumtypeMaster albumTypeMaster);
        List<string> GetAllAlbums();
        List<AlbumtypeMaster> GetAlbumById(int genreid);
    }
}
