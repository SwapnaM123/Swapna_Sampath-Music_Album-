﻿//using Music.Album.Api.Models;
using Music.Album.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Music.Album.Data.Services.Abstract
{
    public interface IGenreService
    {
        GenreMaster CreateGenre(GenreMaster genreMaster);
        GenreMaster UpdateGenre(GenreMaster genreMaster);
        GenreMaster DeleteGenre(GenreMaster genreMaster);
        GenreMaster GetByIdGenre(GenreMaster genreMaster);
        List<GenreMaster> GetAllGenre();
    }
}
