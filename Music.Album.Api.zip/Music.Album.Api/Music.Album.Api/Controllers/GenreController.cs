﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Music.Album.Api.Business.Abstract;
using Music.Album.Data.Models;
//using Music.Album.Api.Models;

namespace Music.Album.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GenreController : ControllerBase
    {
        IGenreContext _igenreContext;
        IConfiguration _iconfiguration;
        public GenreController(IGenreContext igenreContext, IConfiguration iconfiguration)
        {
            _igenreContext = igenreContext;
            _iconfiguration = iconfiguration;
        }
        [HttpPost("CreateGenre")]
        public IActionResult CreateGenre(GenreMaster genreMaster)
        {
            var resp = _igenreContext.CreateGenre(genreMaster);
            if (resp != null)
            {
                return Ok(new { status = 200, success = true, data = "Genre Registered" });
            }
            else
            {
                return Ok(new { status = 401, success = false, data = "Genre Not registered" });
            }
        }

        [HttpPost("UpdateGenre")]
        public IActionResult UpdateGenre(GenreMaster genreMaster)
        {
            var resp = _igenreContext.UpdateGenre(genreMaster);
            if (resp != null)
            {
                return Ok(new { status = 200, success = true, data = resp });
            }
            else
            {
                return Ok(new { status = 401, success = false, data = "Genre Not updated" });
            }
        }

        [HttpPost("DeleteGenre")]
        public IActionResult DeleteGenre(GenreMaster genreMaster)
        {
            var resp = _igenreContext.DeleteGenre(genreMaster);
            if (resp != null)
            {
                return Ok(new { status = 200, success = true, data = "Ge Deleted Successfully" });
            }
            else
            {
                return Ok(new { status = 401, success = false, data = "Album not deleted" });
            }
        }

        [HttpGet("GetAllGenre")]
        public IActionResult GetAllGenre()
        {
            List<GenreMaster> resp = _igenreContext.GetAllGenre();
            if (resp != null)
            {
                return Ok(new { status = 200, success = true, data = resp });
            }
            else
            {
                return Ok(new { status = 401, success = false, data = "Genre not found" });
            }
        }

        [HttpPost("GetByIdGenre")]
        public IActionResult GetByIdGenre(GenreMaster genreMaster)
        {
            GenreMaster resp = _igenreContext.GetByIdGenre(genreMaster);
            if (resp != null)
            {
                return Ok(new { status = 200, success = true, data = resp });
            }
            else
            {
                return Ok(new { status = 401, success = false, data = "Genre not found" });
            }
        }

    }
}
