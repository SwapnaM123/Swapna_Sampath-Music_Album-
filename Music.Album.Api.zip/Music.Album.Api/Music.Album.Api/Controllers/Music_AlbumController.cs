﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Music.Album.Api.Business.Abstract;
using Music.Album.Data.Models;
//using Music.Album.Api.Models;

namespace Music.Album.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Music_AlbumController : ControllerBase
    {
        IMasterContext _iMasterContext;
        IConfiguration _iconfiguration;

        public Music_AlbumController(IMasterContext iMasterContext, IConfiguration iconfiguration)
        {
            _iMasterContext = iMasterContext;
            _iconfiguration = iconfiguration;
        }

        [HttpPost("CreateAlbum")]
        public IActionResult CreateAlbum(AlbumtypeMaster albumTypeMaster)
        {
            var resp = _iMasterContext.CreateAlbum(albumTypeMaster);
            if (resp != null)
            {
                return Ok(new { status = 200, success = true, data = "Album Registered" });
            }
            else
            {
                return Ok(new { status = 401, success = false, data = "Album Not registered" });
            }
        }

        [HttpPost("UpdateAlbum")]
        public IActionResult UpdateAlbum(AlbumtypeMaster albumTypeMaster)
        {
            var resp = _iMasterContext.UpdateAlbum(albumTypeMaster);
            if (resp != null)
            {
                return Ok(new { status = 200, success = true, data = resp });
            }
            else
            {
                return Ok(new { status = 401, success = false, data = "Album Not updated" });
            }
        }

        [HttpPost("DeleteAlbum")]
        public IActionResult DeleteAlbum(AlbumtypeMaster albumTypeMaster)
        {
            var resp = _iMasterContext.UpdateAlbum(albumTypeMaster);
            if (resp != null)
            {
                return Ok(new { status = 200, success = true, data = "Album Deleted Successfully" });
            }
            else
            {
                return Ok(new { status = 401, success = false, data = "Album not deleted" });
            }
        }

        [HttpGet("GetAllAlbums")]
        public IActionResult GetAllAlbums()
        {
            var result = _iMasterContext.GetAllAlbums();
            if (result != null)
            {
                var response = Ok(new { Albums = result });
                return response;
            }
            else
            {
                var response = Ok(new { ErrorMessage = "not found" });
                return response;
            }
        }
        [HttpGet("GetAlbumById")]
        public IActionResult GetAlbumById(int genreid)
        {
            var result = _iMasterContext.GetAlbumById(genreid);
            if (result != null)
            {
                var response = Ok(new { Album = result });
                return response;
            }
            else
            {
                var response = Ok(new { ErrorMessage = "not found" });
                return response;
            }

        }

    }
}
