﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Music.Album.Api.Business.Abstract;
using Music.Album.Data.Models;
//using Music.Album.Api.Models;

namespace Music.Album.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ArtistController : ControllerBase
    {
        IArtistContext _iartistContext;
        IConfiguration _iconfiguration;

        public ArtistController(IArtistContext iartistContext, IConfiguration iconfiguration)
        {
            _iartistContext = iartistContext;
            _iconfiguration = iconfiguration;
        }
        [HttpPost("CreateArtist")]
        public IActionResult CreateArtist(ArtistMaster artistMaster)
        {
            var resp = _iartistContext.CreateArtist(artistMaster);
            if (resp != null)
            {
                return Ok(new { status = 200, success = true, data = "Artist Registered" });
            }
            else
            {
                return Ok(new { status = 401, success = false, data = "Artist Not registered" });
            }
        }
        [HttpPost("UpdateArtist")]
        public IActionResult UpdateArtist(ArtistMaster artistMaster)
        {
            var resp = _iartistContext.UpdateArtist(artistMaster);
            if (resp != null)
            {
                return Ok(new { status = 200, success = true, data = resp });
            }
            else
            {
                return Ok(new { status = 401, success = false, data = "Artist Not updated" });
            }
        }
        [HttpPost("DeleteArtist")]
        public IActionResult DeleteArtist(ArtistMaster artistMaster)
        {
            var resp = _iartistContext.DeleteArtist(artistMaster);
            if (resp != null)
            {
                return Ok(new { status = 200, success = true, data = "Artist Deleted Successfully" });
            }
            else
            {
                return Ok(new { status = 401, success = false, data = "Artist not deleted" });
            }
        }
        
        [HttpGet("GetAllArtists")]
        public IActionResult GetAllArtists()
        {
            var result = _iartistContext.GetAllArtists();
            if (result != null)
            {
                var response = Ok(new { status = 200, success = true, data = result });
                return response;
            }
            else
            {
                var response = Ok(new { status = 401, success = false, data = "not found" });
                return response;
            }
        }
        [HttpGet("GetArtistById")]
        public IActionResult GetArtistById(int titleid)
        {
            var result = _iartistContext.GetArtistById(titleid);
            if (result != null)
            {
                var response = Ok(new { status = 200, success = true, data = result });
                return response;
            }
            else
            {
                var response = Ok(new { status = 401, success = false, data = "not found" });
                return response;
            }

        }

    }
}

