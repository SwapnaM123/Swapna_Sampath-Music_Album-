﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Music.Album.Api.Business.Abstract;
using Music.Album.Data.Models;
//using Music.Album.Api.Models;

namespace Music.Album.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TitleController : ControllerBase
    {
        ITitleContext _titleContext;
        IConfiguration _iconfiguration;

        public TitleController(ITitleContext titleContext, IConfiguration iconfiguration)
        {
            _titleContext = titleContext;
            _iconfiguration = iconfiguration;
        }
        [HttpPost("CreateTitle")]
        public IActionResult CreateTitle(TitleMaster titleMaster)
        {
            var resp = _titleContext.CreateTitle(titleMaster);
            if (resp != null)
            {
                return Ok(new { status = 200, success = true, data = "Album Registered" });
            }
            else
            {
                return Ok(new { status = 401, success = false, data = "Album Not registered" });
            }
        }
        [HttpPost("UpdateTitle")]
        public IActionResult UpdateTitle(TitleMaster titleMaster)
        {
            var resp = _titleContext.UpdateTitle(titleMaster);
            if (resp != null)
            {
                return Ok(new { status = 200, success = true, data = resp });
            }
            else
            {
                return Ok(new { status = 401, success = false, data = "Title Not updated" });
            }
        }
        [HttpPost("DeleteTitle")]
        public IActionResult DeleteTitle(TitleMaster titleMaster)
        {
            var resp = _titleContext.DeleteTitle(titleMaster);
            if (resp != null)
            {
                return Ok(new { status = 200, success = true, data = "Title Deleted Successfully" });
            }
            else
            {
                return Ok(new { status = 401, success = false, data = "Title not deleted" });
            }
        }
        [HttpGet("GetAllTitles")]
        public IActionResult GetAllTitles()
        {
            var result = _titleContext.GetAllTitles();
            if (result != null)
            {
                var response = Ok(new { Songs = result });
                return response;
            }
            else
            {
                var response = Ok(new { status = 401, success = false, data = "not found" });
                return response;
            }
        }
        [HttpGet("GetTitleById")]
        public IActionResult GetTitleById(int albumid)
        {
            var result = _titleContext.GetTitleById(albumid);
            if (result != null)
            {
                var response = Ok(new { status = 200, success = true, data = result });
                return response;
            }
            else
            {
                var response = Ok(new { status = 401, success = false, data = "not found" });
                return response;
            }

        }
    }
}
