﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Music.Album.Api.Business.Abstract;
using Music.Album.Data.Models;
//using Music.Album.Api.Models;

namespace Music.Album.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MusicController : ControllerBase
    {
        IMusicContext _imusicContext;
        IConfiguration _iconfiguration;

        public MusicController(IMusicContext imusicContext, IConfiguration iconfiguration)
        {
            _imusicContext = imusicContext;
            _iconfiguration = iconfiguration;
        }
        [HttpPost("CreateMusic")]
        public IActionResult CreateMusic(MusicMaster musicMaster)
        {
            var resp = _imusicContext.CreateMusic(musicMaster);
            if (resp != null)
            {
                return Ok(new { status = 200, success = true, data = "Music Registered" });
            }
            else
            {
                return Ok(new { status = 401, success = false, data = "Music Not registered" });
            }
        }

        [HttpPost("UpdateMusic")]
        public IActionResult UpdateMusic(MusicMaster musicMaster)
        {
            var resp = _imusicContext.UpdateMusic(musicMaster);
            if (resp != null)
            {
                return Ok(new { status = 200, success = true, data = resp });
            }
            else
            {
                return Ok(new { status = 401, success = false, data = "Music Not updated" });
            }
        }

        [HttpPost("DeleteMusic")]
        public IActionResult DeleteMusic(MusicMaster musicMaster)
        {
            var resp = _imusicContext.DeleteMusic(musicMaster);
            if (resp != null)
            {
                return Ok(new { status = 200, success = true, data = "Music Deleted Successfully" });
            }
            else
            {
                return Ok(new { status = 401, success = false, data = "Music not deleted" });
            }
        }

        [HttpGet("GetAllMusics")]
        public IActionResult GetAllMusics()
        {
            var result = _imusicContext.GetAllMusics();
            if (result != null)
            {
                var response = Ok(new { status = 200, success = true, data = result });
                return response;
            }
            else
            {
                var response = Ok(new { status = 401, success = false, data = "not found" });
                return response;
            }
        }

        [HttpGet("GetMusicById")]
        public IActionResult GetMusicById(MusicMaster musicMaster)
        {
            var result = _imusicContext.GetMusicById(musicMaster);
            if (result != null)
            {
                var response = Ok(new { status = 200, success = true, data = result });
                return response;
            }
            else
            {
                //JsonErrors k = new CustomExceptions(ErrorCodes.error1.ToString(), _configuration).GetErrorObject();
                //return Ok(k);
                var response = Ok(new { status = 401, success = false, data = "not found" });
                return response;
            }

        }

        [HttpPost("GetMusic")]
        public IActionResult GetMusic(MusicDetailsViewModel m)
        {
            var result = _imusicContext.GetMusic(m);
            if (result != null)
            {
                var response = Ok(new { Album = result });
                return response;
            }
            else
            {
                var response = Ok(new { status = 401, success = false, data = "Not found" });
                return response;
            }

        }

    }
}
