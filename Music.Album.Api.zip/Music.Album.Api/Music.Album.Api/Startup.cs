using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Music.Album.Api.Business.Abstract;
using Music.Album.Api.Business.Derived;
using Music.Album.Data.Models;
//using Music.Album.Api.Models;
using Music.Album.Data.Services.Abstract;
using Music.Album.Data.Services.Derived;

namespace Music.Album.Api
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();
            services.AddDbContext<musicContext>(options => options.UseMySQL("Server=127.0.0.1;port=3306;Database=music;Uid=root;Pwd=Mysql@123"));
            services.AddTransient<IMasterContext, MasterContext>();
            services.AddTransient<IMasterService, MasterService>();
            services.AddTransient<ITitleContext, TitleContext>();
            services.AddTransient<ITitleService, TitleService>();
            services.AddTransient<IArtistContext, ArtistContext>();
            services.AddTransient<IArtistService, ArtistService>();
            services.AddTransient<IGenreContext, GenreContext>();
            services.AddTransient<IGenreService, GenreService>();
            services.AddTransient<IMusicContext, MusicContext>();
            services.AddTransient<IMusicService, MusicService>();

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
