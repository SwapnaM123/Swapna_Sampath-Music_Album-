﻿//using Music.Album.Api.Models;

using Music.Album.Api.Business.Abstract;
using Music.Album.Data.Models;
using Music.Album.Data.Services.Abstract;
using System;
using System.Collections.Generic;

namespace Music.Album.Api.Business.Derived
{
    public class MusicContext : IMusicContext
    {
        private readonly IMusicService _musicService;
        public MusicContext(IMusicService musicService)
        {
            _musicService = musicService;
        }

        public MusicMaster CreateMusic(MusicMaster musicMaster)
        {
            return _musicService.CreateMusic(musicMaster);
        }

        public MusicMaster DeleteMusic(MusicMaster musicMaster)
        {
            return _musicService.DeleteMusic(musicMaster);
        }

        public List<MusicMaster> GetAllMusics()
        {
            return _musicService.GetAllMusics();
        }

        public Object GetMusic(MusicDetailsViewModel m)
        {
            return _musicService.GetMusic(m);
        }

        public MusicMaster GetMusicById(MusicMaster musicMaster)
        {
            return _musicService.GetMusicById(musicMaster);
        }

        public MusicMaster UpdateMusic(MusicMaster musicMaster)
        {
            return _musicService.UpdateMusic(musicMaster);
        }
    }
}
