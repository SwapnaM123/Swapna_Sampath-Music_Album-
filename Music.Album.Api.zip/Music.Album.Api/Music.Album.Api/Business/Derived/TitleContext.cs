﻿using Music.Album.Api.Business.Abstract;
using Music.Album.Data.Models;
//using Music.Album.Api.Models;
using Music.Album.Data.Services.Abstract;
using Music.Album.Data.Services.Derived;
using System.Collections.Generic;

namespace Music.Album.Api.Business.Derived
{
    public class TitleContext : ITitleContext
    {
        private readonly ITitleService _titleService;
        public TitleContext(ITitleService titleService)
        {
            _titleService = titleService;
        }
        public TitleMaster CreateTitle(TitleMaster titleMaster)
        {
            return _titleService.CreateTitle(titleMaster);
        }

        public TitleMaster DeleteTitle(TitleMaster titleMaster)
        {
            return _titleService.DeleteTitle(titleMaster);
        }

        public List<string> GetAllTitles()
        {
            return _titleService.GetAllTitles();
        }

        public List<TitleMaster> GetTitleById(int albumid)
        {
            return _titleService.GetTitleById(albumid);
        }

        public TitleMaster UpdateTitle(TitleMaster titleMaster)
        {
            return _titleService.UpdateTitle(titleMaster);
        }
        
    }
}
