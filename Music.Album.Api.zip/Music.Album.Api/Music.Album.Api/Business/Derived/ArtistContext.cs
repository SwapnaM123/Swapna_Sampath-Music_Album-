﻿//using Music.Album.Api.Models;

using Music.Album.Api.Business.Abstract;
using Music.Album.Data.Models;
using Music.Album.Data.Services.Abstract;
using System.Collections.Generic;

namespace Music.Album.Api.Business.Derived
{
    public class ArtistContext : IArtistContext
    {
        private readonly IArtistService _artistService;
        public ArtistContext(IArtistService artistService)
        {
            _artistService = artistService;
        }
        public ArtistMaster CreateArtist(ArtistMaster artistMaster)
        {
            return _artistService.CreateArtist(artistMaster);
        }

        public ArtistMaster DeleteArtist(ArtistMaster artistMaster)
        {
            return _artistService.DeleteArtist(artistMaster);
        }

        public ArtistMaster GetArtistById(int titleid)
        {
            return _artistService.GetArtistById(titleid);
        }

        public List<ArtistMaster> GetAllArtists()
        {
            return _artistService.GetAllArtists();
        }

        public ArtistMaster UpdateArtist(ArtistMaster artistMaster)
        {
            return _artistService.UpdateArtist(artistMaster);
        }


    }
}
