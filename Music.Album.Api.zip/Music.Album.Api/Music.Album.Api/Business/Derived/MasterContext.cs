﻿using Music.Album.Api.Business.Abstract;
//using Music.Album.Api.Models;
using Music.Album.Data.Models;
using Music.Album.Data.Services.Abstract;
using System.Collections.Generic;

namespace Music.Album.Api.Business.Derived
{
    public class MasterContext : IMasterContext
    {
        private readonly IMasterService _masterService;


        public MasterContext(IMasterService masterService)
        {
            _masterService = masterService;
        }

        public AlbumtypeMaster CreateAlbum(AlbumtypeMaster albumTypeMaster)
        {
            return _masterService.CreateAlbum(albumTypeMaster);
        }

        public AlbumtypeMaster DeleteAlbum(AlbumtypeMaster albumTypeMaster)
        {
            return _masterService.DeleteAlbum(albumTypeMaster);
        }

        public List<AlbumtypeMaster> GetAlbumById(int genreid)
        {
            return _masterService.GetAlbumById(genreid);
        }

        public List<string> GetAllAlbums()
        {
            return _masterService.GetAllAlbums();
        }

        public AlbumtypeMaster UpdateAlbum(AlbumtypeMaster albumTypeMaster)
        {
            return _masterService.UpdateAlbum(albumTypeMaster);
        }
    }
}

