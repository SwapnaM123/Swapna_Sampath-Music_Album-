﻿//using Music.Album.Api.Models;

using Music.Album.Api.Business.Abstract;
using Music.Album.Data.Models;
using Music.Album.Data.Services.Abstract;
using System.Collections.Generic;

namespace Music.Album.Api.Business.Derived
{
    public class GenreContext : IGenreContext
    {
        private readonly IGenreService _genreService;
        public GenreContext(IGenreService genreService)
        {
            _genreService = genreService;
        }
        public GenreMaster CreateGenre(GenreMaster genreMaster)
        {
            return _genreService.CreateGenre(genreMaster);
        }

        public GenreMaster DeleteGenre(GenreMaster genreMaster)
        {
            return _genreService.DeleteGenre(genreMaster);
        }

        public List<GenreMaster> GetAllGenre()
        {
            return _genreService.GetAllGenre();
        }

        public GenreMaster GetByIdGenre(GenreMaster genreMaster)
        {
            return _genreService.GetByIdGenre(genreMaster);
        }

        public GenreMaster UpdateGenre(GenreMaster genreMaster)
        {
            return _genreService.UpdateGenre(genreMaster);
        }
    }
}
