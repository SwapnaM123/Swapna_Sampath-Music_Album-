﻿using Music.Album.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;



namespace Music.Album.Api.Business.Abstract
{
    public interface IMasterContext
    {
        AlbumtypeMaster CreateAlbum(AlbumtypeMaster albumTypeMaster);
        AlbumtypeMaster UpdateAlbum(AlbumtypeMaster albumTypeMaster);
        AlbumtypeMaster DeleteAlbum(AlbumtypeMaster albumTypeMaster);
        List<string> GetAllAlbums();
        List<AlbumtypeMaster> GetAlbumById(int genreid);
    }
}
