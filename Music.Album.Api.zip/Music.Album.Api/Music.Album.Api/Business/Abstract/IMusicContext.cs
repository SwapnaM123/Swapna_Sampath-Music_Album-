﻿//using Music.Album.Api.Models;

using Music.Album.Data.Models;
using System;
using System.Collections.Generic;

namespace Music.Album.Api.Business.Abstract
{
    public interface IMusicContext
    {
        MusicMaster CreateMusic(MusicMaster musicMaster);
        MusicMaster UpdateMusic(MusicMaster musicMaster);
        MusicMaster DeleteMusic(MusicMaster musicMaster);
        List<MusicMaster> GetAllMusics();
        MusicMaster GetMusicById(MusicMaster musicMaster);
        Object GetMusic(MusicDetailsViewModel m);
    }
}
