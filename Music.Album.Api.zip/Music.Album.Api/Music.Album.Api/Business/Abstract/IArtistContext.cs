﻿//using Music.Album.Api.Models;
using Music.Album.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Music.Album.Api.Business.Abstract
{
    public interface IArtistContext
    {
        ArtistMaster CreateArtist(ArtistMaster artistMaster);
        ArtistMaster UpdateArtist(ArtistMaster artistMaster);
        ArtistMaster DeleteArtist(ArtistMaster artistMaster);
        List<ArtistMaster> GetAllArtists();
        ArtistMaster GetArtistById(int titleid);
    }
}
