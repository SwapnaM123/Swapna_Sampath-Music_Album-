﻿//using Music.Album.Api.Models;
using Music.Album.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Music.Album.Api.Business.Abstract
{
    public interface ITitleContext
    {
        TitleMaster CreateTitle(TitleMaster titleMaster);
        TitleMaster UpdateTitle(TitleMaster titleMaster);
        TitleMaster DeleteTitle(TitleMaster titleMaster);
        List<string> GetAllTitles();
        List<TitleMaster> GetTitleById(int albumid);
    }
}
