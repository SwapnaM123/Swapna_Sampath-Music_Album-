﻿//using Music.Album.Api.Models;
using Music.Album.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Music.Album.Api.Business.Abstract
{
    public interface IGenreContext
    {
        GenreMaster CreateGenre(GenreMaster genreMaster);
        GenreMaster UpdateGenre(GenreMaster genreMaster);
        GenreMaster DeleteGenre(GenreMaster genreMaster);
        GenreMaster GetByIdGenre(GenreMaster genreMaster);
        List<GenreMaster> GetAllGenre();
    }
}
